Hey! 

Good luck in figuring out what is (if anything) wrong with this model.

As a small tip, we will share the following:

Test for data imbalance in the original dataset and if this is an issue for this model.

Enjoy!