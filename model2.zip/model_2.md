Hey! 

Good luck in figuring out what is (if anything) wrong with this model.

As a small tip, we will share the following:

Test for biases in multiple features highly representative in the original dataset. Consider somewhere between 2 and 4 biases.

Enjoy!